<a href="<?php echo url_for('invoice/selectInterval?id='.$company->getId(), array('title'=>'Generate Invoice')); ?>">
	<?php echo image_tag('/images/invoice.gif'); ?>
</a>