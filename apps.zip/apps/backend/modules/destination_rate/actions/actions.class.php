<?php

/**
 * destination_rate actions.
 *
 * @package    zapnacrm
 * @subpackage destination_rate
 * @author     Your name here
 * @version    SVN: $Id: actions.class.php 5125 2007-09-16 00:53:55Z dwhittle $
 */
class destination_rateActions extends autodestination_rateActions
{
}
