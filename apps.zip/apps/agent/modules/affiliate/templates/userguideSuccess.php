<style>
    #basic p {
    border-bottom: 0px solid #fff;
    }
</style>
<?php foreach ($Userguide as $userguide): ?>
  <?php echo '<h1> '.$userguide->getTitle().'</h1>';
  if($userguide->getImage()!=''){?>
  <img src="<?php echo image_path('../uploads/userguide/'.$userguide->getImage()) ?>" alt="" width="160" /><br /><br />


  <?php }
  echo '<p style=nowrap><b><font size=2></font></b>&nbsp;'.$userguide->getDescription();
  echo '</p>';?>
<?php endforeach; ?>
<!--
<h1>User guide til hvordan Zapna Global fungere p&aring; Windows mobil</h1>
  <p>Ved at f&oslash;lge disse f&aring; trin kan du skifte mellem din nuv&aelig;rende 
  operator og Zapna global.</p>
  
  
<ol>
  <li>
    <p>V&aelig;lg &#8220;start&#8221; og v&aelig;lg &#8220;programmer&#8221; og 
      Zapna</p>
    <p> <img src="http://customer.zerocall.com/zerocall/images/userguides/windows_mobile/programmer.png" alt="" /> 
      <img src="http://customer.zerocall.com/zerocall/images/userguides/windows_mobile/zapna_menu.png" alt="" style="margin-left: 100px" /> 
    </p>
  </li>
  <li><p>V&aelig;lg &#8220;Zapna Global&#8221; og v&aelig;lg &#8221;global&#8221;</p>
    <p> <img src="http://customer.zerocall.com/zerocall/images/userguides/windows_mobile/zapna_global.png" alt="" /> 
      <img src="http://customer.zerocall.com/zerocall/images/userguides/windows_mobile/global.png" alt="" style="margin-left: 100px" /> 
    </p>  
  </li>
  <li><p>V&aelig;lg &#8220;Confirm&#8221; og v&aelig;lg &#8221;ok&#8221; til reboot 
    telefonen</p>
    <p> <img src="http://customer.zerocall.com/zerocall/images/userguides/windows_mobile/confirm.png" alt="" /> 
      <img src="http://customer.zerocall.com/zerocall/images/userguides/windows_mobile/sim_activated.png" alt="" style="margin-left: 100px" /> 
    </p> 	
	</li>
</ol>

	<p>
  Nu skifter du til Zapna global og du kan ringe hjem billigt. N&aring;r du ringer 
  ligger telefonen p&aring; og f&aring; sekunder efter modtager du opkald som 
  du skal besvarer og du bliver forbundet. (ignorer evt. beskeder der kommer p&aring; 
  sk&aelig;rmen)</p>
  <img src="http://customer.zerocall.com/zerocall/images/userguides/windows_mobile/call.png" alt="" style="margin-left: 40px" />
  
  <h1>User guide til hvordan Zapna Global fungere p&aring; Iphone</h1>
<p>Ved at f&oslash;lge disse f&aring; trin kan du skifte mellem din nuv&aelig;rende 
operator og Zapna global.</p>

<ol>
	<li>
		<p>V&aelig;lg &#8220;instillinger&#8221; og v&aelig;lg &#8220;Telefon&#8221;</p>
		<img src="http://customer.zerocall.com/zerocall/images/userguides/iphone/installer.png" alt="" /> 
      	<img src="http://customer.zerocall.com/zerocall/images/userguides/iphone/telephone.png" alt="" style="margin-left: 100px" /> 		
	</li>
	<li>
		<p>V&aelig;lg &#8220;Sim programmer&#8221; og v&aelig;lg &#8220;Zapna Global&#8221;</p>
		<img src="http://customer.zerocall.com/zerocall/images/userguides/iphone/programmer.png" alt="" /> 
      	<img src="http://customer.zerocall.com/zerocall/images/userguides/iphone/zapna_global.png" alt="" style="margin-left: 65px" /> 		
	</li>
	<li>
		<p>V&aelig;lg &#8221;Global&#8221; og v&aelig;lg &#8220;Confirm&#8221;</p>
		<img src="http://customer.zerocall.com/zerocall/images/userguides/iphone/global.png" alt="" /> 
      	<img src="http://customer.zerocall.com/zerocall/images/userguides/iphone/confirm.png" alt="" style="margin-left: 90px" /> 		
	</li>
	<li>
		<p>V&aelig;lg &#8221;Accepter&#8221; til viderestilling</p>
		<img src="http://customer.zerocall.com/zerocall/images/userguides/iphone/accept.png" alt="" /> 
	</li>
</ol>
<p>
  Nu skifter du til Zapna global og du kan ringe hjem billigt. N&aring;r du ringer 
  ligger telefonen p&aring; og f&aring; sekunder efter modtager du opkald som 
  du skal besvarer og du bliver forbundet.
</p>
 <img src="http://customer.zerocall.com/zerocall/images/userguides/iphone/call.png" alt="" style="margin-left: 40px" /> 
   -->
