<h1>Edit Employee</h1>

<?php include_partial('form', array('form' => $form)) ?>
