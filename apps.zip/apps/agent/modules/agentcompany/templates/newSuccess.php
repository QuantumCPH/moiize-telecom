<h1>New Agentcompany</h1>

<?php include_partial('form', array('form' => $form)) ?>
