<?php use_helper('I18N') ?>
<?php use_helper('Number') ?>
<?php include_stylesheets_for_form($form) ?>
<?php include_javascripts_for_form($form) ?>
<?php
$relay_script_url = sfConfig::get('app_epay_relay_script_url');
 
$customer_form = new CustomerForm();
$customer_form->unsetAllExcept(array('auto_refill_amount', 'auto_refill_min_balance'));
?>

<script type="text/javascript">
	$(document).ready(function(){
		$("#quantity").blur(function(){
			if(isNaN($("#quantity").val()) || $("#quantity").val()<1)
			{
				//$('#quantity_ok').hide();
				//$('#quantity_decline').show();
				
				//$('#quantity_error').show();
				$('#quantity').val(1);
				calc();
				
			}
			else
			{
				$('#quantity_decline').hide();
				$('#quantity_ok').show();
				
				//$('#quantity_error').hide();
			}
		});
	
		$('#quantity').change(function(){
			calc();
		});
		
		/* control was later changed to drop down box
		$('#user_attr_3').blur(function(){
			if ( this.value<0 || this.value>400 || isNaN(this.value) )
				this.value = 0;
		});
		*/
		
		toggleAutoRefill();
	
	});
	
	function toggleAutoRefill()
	{
		document.getElementById('user_attr_2').disabled = ! document.getElementById('user_attr_1').checked;
		document.getElementById('user_attr_3').disabled = ! document.getElementById('user_attr_1').checked;
                if(document.getElementById('user_attr_1').checked){
                $("#autorefilop").html('<input type="hidden" name="maketicket" value="foo" />');
		}else{
                    
                     $("#autorefilop").html('');  
                }
	}
	
	function checkForm()
	{
	
		calc();
		
		var objForm = document.getElementById("payment");
		var valid = true;
		
		if(isNaN(objForm.amount.value) || objForm.amount.value <=0 )
		{

			valid = false;
			
		}
		
		if(isNaN(objForm.quantity.value) || objForm.quantity.value<1)
		{
			//if (valid) //still not declarted as invaid
			objForm.quanity.focus();
			$('#quantity_decline').show();
			valid = false;
		}
		else
			$('#quantity_ok').show();
		
		
		
		//if (!valid)
		//	alert('Please complete out the payment form.');
		
		return valid;
	}
	
	function calc()
	{
		var product_price = $('#product_price').val();
		var quantity = $('#quantity').val();
			var postal=  $('#postal').val();
		var extra_refill = $('#extra_refill').val();
		
		var cf_options = {
		  decimalSymbol: ',',
		  digitGroupSymbol: '.',
		  dropDecimals: true,
		  groupDigits: true,
		  symbol: '',
		  roundToDecimalPlace: 2
		};
		
		
		$('#extra_refill_span').text(extra_refill); //update the vat span
		
		//var vat = .20 * (parseFloat(product_price) * parseFloat(quantity));
		var vat = .25 * (parseFloat(product_price) * parseFloat(quantity));
	
		$('#vat').val(vat);


		$('#vat_span').text(vat);
		$('#vat_span').formatCurrency(cf_options);
		
		var total = Math.ceil(parseFloat(product_price) * parseFloat(quantity) + parseFloat(extra_refill) + parseFloat(vat)+ parseFloat(postal));
		$('#total_span').text(total);
		$('#total_span').formatCurrency(cf_options);
		$('#total').val(total*100);
                att2= $('#user_attr_2').val();
                att3= $('#user_attr_3').val();
                var accepturlstr = "<?php echo $relay_script_url.url_for('@epay_accept_url', true);  ?>?user_attr_2="+att2+"&user_attr_3="+att3+"&accept=yes&subscriptionid=1&orderid=<?php echo $order_id; ?>&amount="+total*100;
                 var callbackurlstr = "<?php echo $relay_script_url.url_for('@dibs_accept_url', true);  ?>?user_attr_2="+att2+"&user_attr_3="+att3+"&accept=yes&subscriptionid=3&orderid=<?php echo $order_id; ?>&amount="+total*100;
                $('#idaccepturl').val(accepturlstr);

                 if(document.getElementById('user_attr_1').checked){
                $('#idcallbackurl').val(callbackurlstr);
                 }else{
                     var callbackurlstrs = "<?php echo $relay_script_url.url_for('@dibs_accept_url', true);  ?>?accept=yes&subscriptionid=1&orderid=<?php echo $order_id; ?>&amount="+total*100;
                    $('#idcallbackurl').val(callbackurlstrs);
                 }
	}
	
	
	
	
</script>
 <?php
                $lang =  'de';
                //$this->lang = $lang;
                $countrylng = new Criteria();
                $countrylng->add(EnableCountryPeer::LANGUAGE_SYMBOL, $lang);
                $countrylng = EnableCountryPeer::doSelectOne($countrylng);
                if($countrylng){
                    $countryName = $countrylng->getName();
                    $languageSymbol = $countrylng->getLanguageSymbol();
                    $lngId = $countrylng->getId();
                    $postalcharges = new Criteria();
                    $postalcharges->add(PostalChargesPeer::COUNTRY, $lngId);
                    $postalcharges->add(PostalChargesPeer::STATUS, 1);
                    $postalcharges = PostalChargesPeer::doSelectOne($postalcharges);
                    if($postalcharges){
                        $postalcharge =  $postalcharges->getCharges();
                    }else{
                        $postalcharge =  0;
                    }
                }


                ?>

<form action="https://payment.architrade.com/paymentweb/start.action"   method="post" id="payment" onsubmit="return checkForm()">
  <div class="left-col">
    <div class="split-form-sign-up">
      <div class="step-details"> <strong><?php echo __('Become a Customer') ?> <span class="inactive">- <?php echo __('Step 1') ?>: <?php echo __('Registrera') ?> </span><span class="active">- <?php echo __('Step 2') ?>: <?php echo __('Payment') ?></span></strong> </div>
      <div class="fl col">
          <ul>

            
            <!-- payment details -->
            <li>
              <label><?php echo __('Payment details') ?>:</label>
            </li>
            <li>
              <label><?php echo $order->getProduct()->getName() ?>
              	<br />
				<?php echo __('Extra refill amount') ?>
			  </label>

              <input type="hidden" id="product_price" value="<?php 
              	$product_price_vat = ($order->getProduct()->getPrice()-$order->getProduct()->getInitialBalance())*.20;

              	$product_price = ($order->getProduct()->getPrice()-$order->getProduct()->getInitialBalance()) - $product_price_vat;
              	
              	echo $product_price;
              	?>" />
              <input type="hidden" id="extra_refill" value="<?php $extra_refill = $order->getExtraRefill(); echo $extra_refill; ?>" />
              
              
              <label class="fr ac">
              	<span class="product_price_span"> <?php echo format_number($product_price) ?> </span>&euro;
              	<br />
              	<span id="extra_refill_span">
					<?php echo format_number($extra_refill) ?>
				</span>&euro;
			  </label>

            </li>
            <?php
            $error_quantity = false;;
            if($form['quantity']->hasError())
            	$error_quantity = true;
            ?>
             <?php if($error_quantity) { ?>
            <li class="error">
            	<?php echo $form['quantity']->renderError() ?>
            </li>
            <?php } ?>  
          
            <li style="display:none">
              <?php echo $form['quantity']->renderLabel() ?>
			  <?php echo $form['quantity'] ?>
			  <span id="quantity_ok" class="alert">
			  	<?php echo image_tag('../zerocall/images/ok.png', array('absolute'=>true)) ?>
			  </span>
			  <span id="quantity_decline" class="alert">
			  	<?php echo image_tag('../zerocall/images/decl.gif', array('absolute'=>true)) ?>
			  </span>
            </li>
            <li>
              <label><?php echo __('VAT') ?> (25%)<br />
                  <?php echo __('Liefer-und Versandkosten') ?> <br />
              <?php echo __('Total amount') ?></label>
              <input type="hidden" id="vat" value="<?php $vat = .25 * ($product_price); echo $vat; ?>" />
                <input type="hidden" id="postal" value="<?php  echo $postalcharge; ?>" />
              <label class="fr ac" >
              	<span id="vat_span">
              	<?php echo format_number($vat) ?>
              	</span>&euro;
                <br /><?php echo $postalcharge;  ?>&nbsp; &euro;
   <br />
              	<?php //$total = $product_price + $extra_refill + $vat ?>
                <?php $total = $product_price + $extra_refill + $vat+ $postalcharge ?>
              	<span id="total_span">
              	<?php echo format_number($total) ?>
              	</span>&euro;
              </label>
            </li>
	
          </ul>
        <!-- hidden fields -->
		<?php echo $form->renderHiddenFields() ?>
		
		<input type="hidden" name="merchant" value="90049676" />
		<input type="hidden" name="amount" id="total" value="<?php echo $total;?>" />
		<input type="hidden" name="currency" value="978" />
		<input type="hidden" name="orderid" value="<?php echo $order_id;?>" />
		<input type="hidden" name="account" value="YTIP" />
		  <input type="hidden" name="addfee" value="0" />
           
                <input type="hidden" name="test" value="yes" />
       
                <div id="autorefilop" >
                    <input type="hidden" name="maketicket" value="foo" />
                </div>
<!--           test credit card info
           4711100000000000
           06
           24
           684-->
         <input type="hidden" name="lang" value="de" />
	
     <input type="hidden" name="status" value="" />
		<input type="hidden" name="cancelurl" value="<?php echo $relay_script_url.url_for('@epay_reject_url', true)  ?>?accept=cancel&subscriptionid=&orderid=<?php echo $order->getId(); ?>&amount=<?php echo $order->getExtraRefill(); ?>" />
                <input type="hidden" name="callbackurl" id="idcallbackurl" value="<?php echo $relay_script_url.url_for('@dibs_accept_url', true);  ?>?accept=yes&subscriptionid=&orderid=<?php echo $order_id; ?>&amount=<?php echo $total; ?>" />
		<input type="hidden" name="accepturl" id="idaccepturl"  value="<?php echo $relay_script_url.url_for('@epay_accept_url', true);  ?>?accept=yes&subscriptionid=&orderid=<?php echo $order_id; ?>&amount=<?php echo $total; ?>" />
		      </div>
      <div class="fr col">
          
        <ul>
            <!-- auto fill -->
            <li>
              <label><?php echo __('Auto refill details:') ?></label>
            </li>
            <li>
            <li>
            	<input type="checkbox" class="fl" style="width:20px;" onchange="toggleAutoRefill()" name="user_attr_1" id="user_attr_1" checked="checked" />
 				<label for="user_attr_1" style="padding-top:0; text-indent: 5px;"><?php echo __('I want to activate auto refill feature') ?></label>
            </li>
            <li id="user_attr_3_field">
                <label for="user_attr_3" style="margin-right: 50px;"><?php echo __('Auto refill minimum balance:') ?>&nbsp;</label>
			  <?php echo $customer_form['auto_refill_min_balance']->render(array(
			  										'name'=>'user_attr_3',
                                                                                                        'id'=>'user_attr_3',
			  										'style'=>'width: 80px;'
			  									)) 
                                  ?>&euro;
            </li>
           <li id="user_attr_2_field">
              <label for="user_attr_2" style="margin-right: 50px;"><?php echo __('Auto refill amount:') ?></label>
     <?php echo $customer_form['auto_refill_amount']->render(array(
                                                            'name'=>'user_attr_2',
         'id'=>'user_attr_2',
         'style'=>'width:80;',
                                                                                                                                                                      'style'=>'width: 80px;'
                 ));  
     ?>
            </li>
            <li id="" style="border-style:solid;border-width:3px;width: 295px; padding-left: 10px;">
                <br /><b>Was ist die automatische Nachschub? </ B> <br />
                 Land nennen empfohlen, diesen Service <br /> aktivieren
                 so müssen Sie nicht ausfüllen manuell, <br /> wenn Ihr Guthaben zur Neige geht. <br />
                 100 oder 200 Kronen einander,  <br />wenn der Kontostand erreicht <br />
                 25 oder 50 Dollar. Füllmenge ist <br /> hinzugefügt
                 Ihr Konto in Minuten. Ihre Füllung <br />
                 Sie können dann sehen, der "Übersicht - Ihr Kredit".
                
                <br /><br />
                                
            </li>
        </ul>
            <input type="submit"  class="butonsigninsmall"  name="paybutan"  style="cursor: pointer;margin-left: 185px;" value="<?php echo __('Pay') ?>">
			
       
      </div>
    </div>
  </div>
</form>

