<?php

/**
 * sale_action actions.
 *
 * @package    zapnacrm
 * @subpackage sale_action
 * @author     Your name here
 * @version    SVN: $Id: actions.class.php 5125 2007-09-16 00:53:55Z dwhittle $
 */
class sale_actionActions extends autosale_actionActions
{
}
