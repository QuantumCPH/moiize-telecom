<h1>New City</h1>

<?php include_partial('form', array('form' => $form)) ?>
