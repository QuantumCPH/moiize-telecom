<h1>Edit Telecom operator</h1>

<?php include_partial('form', array('form' => $form)) ?>
