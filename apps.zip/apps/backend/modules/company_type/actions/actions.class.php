<?php

/**
 * company_type actions.
 *
 * @package    zapnacrm
 * @subpackage company_type
 * @author     Your name here
 * @version    SVN: $Id: actions.class.php 5125 2007-09-16 00:53:55Z dwhittle $
 */
class company_typeActions extends autocompany_typeActions
{
}
