<h1>Edit City</h1>

<?php include_partial('form', array('form' => $form)) ?>
