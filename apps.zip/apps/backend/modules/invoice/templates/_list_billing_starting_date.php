<?php
	echo $invoice->getBillingStartingDate('d F Y');
?>