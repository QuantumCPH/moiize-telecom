  <div class="dashboard">
    <h2><?php //echo __('Welcome') ?> <span><?php echo $section ?></span></h2>
  </div>