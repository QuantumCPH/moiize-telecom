<h1>New Telecom operator</h1>

<?php include_partial('form', array('form' => $form)) ?>
