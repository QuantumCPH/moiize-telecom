<?php
	echo number_format($invoice->getTotalpayment(), 2);
?>