<?php

/**
 * support_activity_status actions.
 *
 * @package    zapnacrm
 * @subpackage support_activity_status
 * @author     Your name here
 * @version    SVN: $Id: actions.class.php 5125 2007-09-16 00:53:55Z dwhittle $
 */
class support_activity_statusActions extends autosupport_activity_statusActions
{
}
