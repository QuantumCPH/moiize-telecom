
<form method="post" action="agentProduct">

  <?php echo $form['agent_company_id']->renderLabel() ?>
             <?php echo $form['agent_company_id'] ?>
    <input type="submit" name="Assign Product" value="Assign Product">



</form>