<?php
?>
<div id="sf_admin_container">
<h1>Run Billing Call Histry Query</h1>
<h1>Please Follow the Date and time structure same as mention</h1>

<div id="sf_admin_header">
</div>

<div id="sf_admin_content">

<form action="" enctype="multipart/form-data" method="post" name="sf_admin_edit_form" id="sf_admin_edit_form">
<fieldset class="" id="sf_fieldset_none">

<div class="form-row">
  <label class="required" for="faqs_question">Time:</label>  <div class="content">
  
  <input type="text" size="80" value="2011-06-17 10:17:42" id="qrytime" name="qrytime" style="width: 240px;">&nbsp;<strong>2011-06-17 10:17:42</strong>    </div>
</div>

<div class="form-row">
  <label class="required" for="faqs_question">Customer id:</label>  <div class="content">
  
  <input type="text" size="80" value="" id="customer_id" name="customer_id" style="width: 240px;">    </div>
</div>

<div class="form-row">
  <label class="required" for="faqs_question">From Mobile number:</label>  <div class="content">
  
  <input type="text" size="80" value="" id="mobile_number" name="mobile_number" style="width: 240px;">    </div>
</div>

<div class="form-row">
  <label class="required" for="faqs_question">To Mobile number:</label>  <div class="content">
  
  <input type="text" size="80" value="" id="to_number" name="to_number" style="width: 240px;">    </div>
</div>

<div class="form-row">
  <label class="required" for="faqs_question">Duration Minutes:</label>  <div class="content">
  
  <input type="text" size="80" value="2:00" id="duration_minutes" name="duration_minutes" style="width: 240px;">&nbsp;<strong>2:00 </strong>   </div>
</div>

<div class="form-row">
  <label class="required" for="faqs_question">Call Cost:</label>  <div class="content">
  
  <input type="text" size="80" value="2.00" id="call_cost" name="call_cost" style="width: 240px;">&nbsp;<strong>2.00</strong>
 </div>
</div>

<div class="form-row">
  <label class="required" for="faqs_question">Cost per minute:</label>  <div class="content">
  
  <input type="text" size="80" value="1.00" id="cost_per_minute" name="cost_per_minute" style="width: 240px;">    </div>
</div>

<div class="form-row">
  <label class="required" for="faqs_question">vat:</label>  <div class="content">
  
  <input type="text" size="80" value="0.5" id="vat" name="vat" style="width: 240px;"> &nbsp;<strong>Call Cost * 4 = vat Like 2.00*4=0.5</strong>    </div>
</div>

<div class="form-row">
  <label class="required" for="faqs_question">Balance Before:</label>  <div class="content">
  
  <input type="text" size="80" value="88.61" id="balance_before" name="balance_before" style="width: 240px;">&nbsp;<strong>88.61</strong>    </div>
</div>

<div class="form-row">
  <label class="required" for="faqs_question">Balance After:</label>  <div class="content">
  
  <input type="text" size="80" value="82.61" id="balance_after" name="balance_after" style="width: 240px;">&nbsp;<strong>88.61</strong>    </div>
</div>

</fieldset>

<ul class="sf_admin_actions">
  <li><input type="submit" class="sf_admin_action_save" value="Add call history" name="update"></li>
</ul>

</form>

<ul class="sf_admin_actions">
      <li class="float-left"></li>
  </ul>
</div>

<div id="sf_admin_footer">
</div>

</div>