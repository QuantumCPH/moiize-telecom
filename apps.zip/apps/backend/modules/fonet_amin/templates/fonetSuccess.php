<?php echo link_to('Information', '/zapnacrm2/backend_dev.php/info')."<br />";
echo link_to('Recharge Customer Balance', '/zapnacrm2/backend_dev.php/recharge')."<br />";
echo link_to('Activate', '/zapnacrm2/backend_dev.php/activate')."<br />";
echo link_to('De-Activate', '/zapnacrm2/backend_dev.php/delete')."<br />";
/*?>
<form action="/backend_dev.php/fonet_amin/fonet" method="GET">
<?php echo link_to('', '/zapnacrm2/backend_dev.php/fonet'); ?>

</form><?php*/?>
