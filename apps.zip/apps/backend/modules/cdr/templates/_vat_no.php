<?php
	echo input_tag('filters[vat_no]', isset($filters['vat_no']) ? $filters['vat_no'] : '')
?>