<?php

/**
 * invoice_method actions.
 *
 * @package    zapnacrm
 * @subpackage invoice_method
 * @author     Your name here
 * @version    SVN: $Id: actions.class.php 5125 2007-09-16 00:53:55Z dwhittle $
 */
class invoice_methodActions extends autoinvoice_methodActions
{
}
