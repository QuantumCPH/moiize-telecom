
<div id="wrap">
    <div style="width:800px;padding-left:250px">
<div style="width:800px;height:80px; float:left;display:block; background-image:url(<?php echo _compute_public_path('logo','zerocall/images','gif')?>); background-repeat:no-repeat; overflow:hidden; text-indent:9000em; white-space:nowrap;">
<h1><a href="http://zerocall.com<?php echo $test_dir ?>/"
	title="Zero Call - Zapna">Zero Call - Zapna - </a></h1>
</div>
<?php echo image_tag('/zerocall/images/bannerb2b.gif') ?>

    
<div style="width:800px">
        <table>
            <tr>
                <td style="background-image:url('<?php echo _compute_public_path('zapna_bg','zerocall/images','jpg')?>');
color:orange;
font-family:sans-serif;
font-weight:450;Height:250px;width:400;text-align: center;
"><b>Til dig som rejser for din virksomhed <br/> <a href="http://customer.zerocall.com/b2c/LandingPages/B2B?visitor=<?php echo $visitor->getId() ?>"> (KLIK HER)</a></b></td>
 
                <td style="background-image:url('<?php echo _compute_public_path('line_bg','zerocall/images','jpg')?>');
font-family:sans-serif;
font-weight:10;Height:250px;width:5
"></td>
                <td style="background-image:url('<?php echo _compute_public_path('zerocall_bg','zerocall/images','jpg')?>');
color:orange;
font-family:sans-serif;
font-weight:450;Height:250px;width:450;text-align: center;
"> <b>Til dig som selv betaler for din telefonregning <br/> <a href="http://customer.zerocall.com/b2c/LandingPages/B2C?visitor=<?php echo $visitor->getId() ?>">(KLIK HER)</a></b></td>
            </tr>
        </table>
        

 <br/>
 <hr style="width:800px;color:#e77714">
 </div>
 <br/>
<div id="cite" class="fl">Copyright &copy; Zapna 2010</div>
<div style="width:800px;text-align: right" id="sec" class="fr"><script type="text/javascript"
	src="https://seal.thawte.com/getthawteseal?host_name=zerocall.com&amp;size=S&amp;lang=en"></script>
</div>
<div style="width:800px;text-align: right" id="ccs" class="fr"><img
	src="<?php echo image_path('../zerocall/images/ccs.png',true) ?>"
	alt="Credit Cards" /></div>
</div>
</div>
