<?php
	//use_helper('I18N');
	//echo __('Ooops!  We are unable to complete the credit card verification process.');
?>