    <div class="signup-steps">
      <div class="step1 <?php echo ($active_step==1?'active':'inactive') ?>"> <small><?php echo __('Step 1'); ?>:</small> <span><?php echo __('Register'); ?></span>
        <p><?php echo __('Enter you mobil number and add your contact info.'); ?>
          </p>
      </div>
      <div class="step2 <?php echo ($active_step==2?'active':'inactive') ?>"> <small><?php echo __('Step 2'); ?>:</small> <span><?php echo __('Payment'); ?></span>
        <p><?php echo __('Select the refill amount and make the payment by credit card'); ?></p>
      </div>
      <div class="step3 <?php echo ($active_step==3?'active':'inactive') ?>"> <small><?php echo __('Step 3'); ?>:</small> <span><?php echo __('Start Calling'); ?></span>
        <p><?php echo __('You can get free calls worldwide'); ?></p>
      </div>
      <div class="support"> <small><?php echo __('Support'); ?>:</small> <span><?php echo __('Questions'); ?>?</span>
        <p><?php echo __('Get instant answers from our customer support from 10.00 - 15.00'); ?></p>
      </div>
    </div> <!-- end signup-steps -->