<?php
	echo link_to($cdr_log->getFromNo(), 'usage/edit?id='.$cdr_log->getId());
?>