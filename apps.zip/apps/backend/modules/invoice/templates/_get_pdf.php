<a href="<?php echo url_for('invoice/getPdf?id='.$invoice->getId()); ?>">
	<?php echo image_tag('/images/pdf.png'); ?>
</a>