<h1>Edit Agentcompany</h1>

<?php include_partial('form', array('form' => $form)) ?>
