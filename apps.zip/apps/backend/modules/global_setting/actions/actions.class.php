<?php

/**
 * global_setting actions.
 *
 * @package    zapnacrm
 * @subpackage global_setting
 * @author     Your name here
 * @version    SVN: $Id: actions.class.php 5125 2007-09-16 00:53:55Z dwhittle $
 */
class global_settingActions extends autoglobal_settingActions
{
}
