<?php use_helper('I18N') ?>
<?php use_helper('Number') ?>

<div class="alert_bar">
	<?php echo __('Call history is updated after every 1 minutes.') ?>
</div>
  <div class="left-col">

<?php if ($customer->getC9CustomerNumber() ):?>
	<div style="clear: both;"></div>
<span style="margin: 20px;">
	<center>

		<form action="/index.php/customer/c9Callhistory" method="post">
			<INPUT TYPE="submit" VALUE="<?php echo __('Se LandNCall AB Global opkaldsoversigt') ?>">
		</form>
	</center>
</span>
<?php endif; ?>
    
       
<?php $unid=$customer->getUniqueid();  ?>


         <table width="70%" cellspacing="0" cellpadding="0" class="callhistory" style="float: left;">
                       <tr>
                           <th align="left"colspan="6">&nbsp; </th>

                      </tr>
                      <tr>
                            <th align="left" colspan="6">
                     <table border="0" cellspacing="4" cellpadding="4" >  <tr  style="background-color: #838483;color:#FFFFFF;padding: 5px;">
                                    <td align="left" ><a  style="background-color: #838483;color:#FFFFFF;text-decoration: none;" href="allRegisteredCustomer"><?php echo  __('View All Customer') ?></a></td>
                                    <td align="left"><a style="background-color: #838483;color:#FFFFFF;text-decoration: none;" href="paymenthistory?id=<?php echo $_REQUEST['id'];  ?>"><?php echo  __('Payment History') ?></a></td>
                                    <td align="left"><a style="background-color: #838483;color:#FFFFFF;text-decoration: none;" href="customerDetail?id=<?php echo $_REQUEST['id'];  ?>"><?php echo  __('Customer Detail') ?></a></td>


                      </tr> </table></th>

                      </tr>
                        <tr>
                            <th align="left" colspan="6">&nbsp;</th>

                      </tr>
                        <tr>
                            <th align="left" colspan="6"  style="background-color: #CCCCFF;color: #000000;text-align: left;"><?php echo  __('Call History') ?></th>

                      </tr>
                    <tr  style="background-color: #CCCCFF;color: #000000;">
                    <th width="20%"   align="left"><?php echo __('Date &amp; time') ?></th>
                    <th  width="20%"  align="left"><?php echo __('Phone Number') ?></th>
                    <th width="10%"   align="left"><?php echo __('Duration') ?></th>
                    <th  width="10%"  align="left"><?php echo __('VAT') ?></th>
                    <th width="20%"   align="left"><?php echo __('Cost <small>(Incl. VAT)</small>') ?></th>
                    <th  width="20%"   align="left"><?php echo  __('Samtalstyp') ?></th>
                  </tr>
   <?php
                $amount_total = 0;




$tomorrow1 = mktime(0,0,0,date("m"),date("d")-15,date("Y"));
$fromdate=date("Y-m-d", $tomorrow1);
$tomorrow = mktime(0,0,0,date("m"),date("d")+1,date("Y"));
 $todate=date("Y-m-d", $tomorrow);




  $getFirstnumberofMobile = substr($customer->getMobileNumber(), 0,1);
                if($getFirstnumberofMobile==0){
                    $TelintaMobile = substr($customer->getMobileNumber(), 1);
                    $TelintaMobile =  '49'.$TelintaMobile ;
                }else{
                    $TelintaMobile = '49'.$customer->getMobileNumber();
                }

 $uniqueId=$customer->getUniqueid();

  $tilentaCallHistryResult=Telienta::callHistory($uniqueId,$fromdate,$todate);
 
  //$urlval = "https://mybilling.telinta.com/htdocs/zapna/zapna.pl?type=customer&action=get_xdrs&name=".$numbername."&tz=Europe/Stockholm&from_date=".$fromdate."&to_date=".$todate;

//No records for the entered period of
$res =$tilentaCallHistryResult;
$csv = new parseCSV();

$csvFileName = $res;
# Parse '_books.csv' using automatic delimiter detection...
$csv->auto($csvFileName);


foreach ($csv->data as $key => $row) {

    $timstampscsv = date('Y-m-d h:i:S');
    $counters = 0;
    foreach ($row as $value) {
?>



<?php

        //echo $value;
        //$sqlInserts .= "'$value'".', ';
//echo $csv->titles[$counters];
        if ($csv->titles[$counters] == 'class') {
            $csv->titles[$counters] = 'lstclasses';
        }
        ${$csv->titles[$counters]} = $value;
        $counters++;
    } ?>


    <tr>
        <td><?php echo $connect_time; ?></td>
        <td><?php echo  $CLD; ?></td>
        <td><?php echo number_format($charged_quantity/60 ,2);  ?></td>
         <td><?php echo  number_format($charged_amount/4,2); ?></td>
        <td><?php echo number_format($charged_amount,2);      $amount_total+= number_format($charged_amount,2); ?> &euro;</td>
           <td><?php $account_id;    $typecall=substr($account_id,0,1);
           if($typecall=='a'){ echo "Int.";  }
           if($typecall=='4'){ echo "R";  }
           if($typecall=='c'){ if($CLI=='**24'){  echo "Cb M"; }else{ echo "Cb S"; }      }  ?> </td>
            </tr>

<?php
$callRecords=1;
}
?>


                <?php if(count($callRecords)==0): ?>
                <tr>
                	<td colspan="6"><p><?php echo __('There are currently no call records to show.') ?></p></td>
                </tr>
                <?php else: ?>
                <tr>
                	<td colspan="4" align="right"><strong><?php echo __('Subtotal') ?></strong></td>
                	<!--
                	<td><?php //echo format_number($amount_total-$amount_total*.20) ?> SEK</td>
                	 -->
                         <td><?php echo number_format($amount_total, 2, ',', '') ?>&euro;</td>
                        <td>&nbsp;</td>
                </tr>
                <?php endif; ?>
                <tr><td colspan="6" align="left"><?php echo  __('Samtalstyp  type detail') ?> <br/> <?php echo  __('Int. = Internationella samtal') ?><br/>
        <?php echo  __('Cb M = Callback mottaga') ?><br/>
	<?php echo  __('Cb S = Callback samtal') ?><br/>
	<?php echo  __('R = resenummer samtal') ?><br/>
</td></tr>
              </table>


     <!-- end split-form -->
  </div> <!-- end left-col -->
