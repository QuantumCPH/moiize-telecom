<?php
	echo $invoice->getBillingEndingDate('d F Y');
?>