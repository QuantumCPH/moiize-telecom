<ul class="sf_admin_actions">
  <li><?php echo button_to(__('create'), 'company/create', array (
  'class' => 'sf_admin_action_create',
)) ?></li>
</ul>
