<?php

/**
 * employee_product actions.
 *
 * @package    zapnacrm
 * @subpackage employee_product
 * @author     Your name here
 * @version    SVN: $Id: actions.class.php 5125 2007-09-16 00:53:55Z dwhittle $
 */
class employee_productActions extends autoemployee_productActions
{
}
