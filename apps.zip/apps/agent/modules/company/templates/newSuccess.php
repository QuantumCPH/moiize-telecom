<h1>New Company</h1>

<?php include_partial('form', array('form' => $form)) ?>
