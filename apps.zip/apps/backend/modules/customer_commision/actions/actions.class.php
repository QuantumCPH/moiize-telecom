<?php

/**
 * customer_commision actions.
 *
 * @package    zapnacrm
 * @subpackage customer_commision
 * @author     Your name here
 */
class customer_commisionActions extends autocustomer_commisionActions
{
}
