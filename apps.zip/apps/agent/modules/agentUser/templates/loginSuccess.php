<?php use_helper('I18N') ?>
<h2><?php echo __('login to account') ?></h2>
<p><?php echo __('provide your e-mail and password') ?></p>
<?php include_partial('loginform', array('form' => $form)) ?>
