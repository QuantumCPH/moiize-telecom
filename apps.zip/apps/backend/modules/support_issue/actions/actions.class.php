<?php

/**
 * support_issue actions.
 *
 * @package    zapnacrm
 * @subpackage support_issue
 * @author     Your name here
 * @version    SVN: $Id: actions.class.php 5125 2007-09-16 00:53:55Z dwhittle $
 */
class support_issueActions extends autosupport_issueActions
{
}
