 <?php echo select_tag('company[city_id]', options_for_select($cities_list, null)) ?>
	   