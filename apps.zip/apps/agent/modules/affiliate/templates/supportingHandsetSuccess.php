<table width="98%" cellspacing="0" cellpadding="3" align="center">
          <tbody>
            <tr style="background-color: #FF6600; color: #fff"> 
              <td><strong>&nbsp;Brand name</strong></td>
              <td><strong>&nbsp;Model</strong></td>
              <td><strong>&nbsp;Callback Test result</strong></td>
              <td><strong>&nbsp;Auto reboot</strong></td>
              <td><strong>&nbsp;Dialer Mode</strong></td>
              <td><strong>&nbsp;Tested by</strong></td>
              <td><strong>&nbsp;Comments</strong></td>
              <td><strong>&nbsp;Zapna out mode</strong></td>
            </tr>
            <tr> 
              <td>&nbsp;Apple</td>
              <td>&nbsp;Iphone</td>
              <td>&nbsp;Supported</td>
              <td>&nbsp;Auto Reboot</td>
              <td>&nbsp;Mode 2</td>
              <td>&nbsp;OKH</td>
              <td>&nbsp;</td>
              <td>&nbsp;1</td>
            </tr>
            <tr> 
              <td>&nbsp;HTC</td>
              <td>&nbsp;Desire</td>
              <td>&nbsp;Supported</td>
              <td>&nbsp;Auto Reboot</td>
              <td>&nbsp;Mode 2</td>
              <td>&nbsp;OKH</td>
              <td>&nbsp;</td>
              <td>&nbsp;3</td>
            </tr>
            <tr> 
              <td>&nbsp;HTC </td>
              <td>&nbsp;Touch diamond 2</td>
              <td>&nbsp;Supported</td>
              <td>&nbsp;Auto Reboot</td>
              <td>&nbsp;Mode 2</td>
              <td>&nbsp;OKH</td>
              <td>&nbsp;</td>
              <td>&nbsp;3</td>
            </tr>
            <tr> 
              <td>&nbsp;HTC </td>
              <td>&nbsp;Touch</td>
              <td>&nbsp;Supported</td>
              <td>&nbsp;Auto Reboot</td>
              <td>&nbsp;Mode 2</td>
              <td>&nbsp;OKH</td>
              <td>&nbsp;</td>
              <td>&nbsp;1</td>
            </tr>
            <tr> 
              <td>&nbsp;Nokia</td>
              <td>&nbsp;E65</td>
              <td>&nbsp;Supported</td>
              <td>&nbsp;Manual</td>
              <td>&nbsp;Mode 1</td>
              <td>&nbsp;OKH</td>
              <td>&nbsp;Deactivation take around 4-5 min before its activated</td>
              <td>&nbsp;1</td>
            </tr>
            <tr> 
              <td>&nbsp;Nokia</td>
              <td>&nbsp;6233</td>
              <td>&nbsp;Supported</td>
              <td>&nbsp;Manual</td>
              <td>&nbsp;Mode 1</td>
              <td>&nbsp;OKH</td>
              <td>&nbsp;Deactivation take around 4-5 min before its activated</td>
              <td>&nbsp;1</td>
            </tr>
            <tr> 
              <td>&nbsp;Nokia</td>
              <td>&nbsp;E71</td>
              <td>&nbsp;Not Supported</td>
              <td>&nbsp;Not Supported</td>
              <td>&nbsp;Not Supported</td>
              <td>&nbsp;OKH</td>
              <td>&nbsp;The phone is not supported</td>
              <td>&nbsp;1</td>
            </tr>
            <tr> 
              <td>&nbsp;Nokia</td>
              <td>&nbsp;E51</td>
              <td>&nbsp;Supported</td>
              <td>&nbsp;Manual</td>
              <td>&nbsp;Mode 1</td>
              <td>&nbsp;OKH</td>
              <td>&nbsp;Deactivation take around 4-5 min before its activated</td>
              <td>&nbsp;1</td>
            </tr>
            <tr> 
              <td>&nbsp;Nokia</td>
              <td>&nbsp;E65</td>
              <td>&nbsp;Supported</td>
              <td>&nbsp;Manual</td>
              <td>&nbsp;Mode 1</td>
              <td>&nbsp;OKH</td>
              <td>&nbsp;Deactivation take around 4-5 min before its activated</td>
              <td>&nbsp;1</td>
            </tr>
            <tr> 
              <td>&nbsp;Nokia</td>
              <td>&nbsp;N73</td>
              <td>&nbsp;Supported</td>
              <td>&nbsp;Manual</td>
              <td>&nbsp;Mode 1</td>
              <td>&nbsp;OKH</td>
              <td>&nbsp;Deactivation take around 4-5 min before its activated</td>
              <td>&nbsp;1</td>
            </tr>
            <tr> 
              <td>&nbsp;Nokia</td>
              <td>&nbsp;N93</td>
              <td>&nbsp;Supported</td>
              <td>&nbsp;Manual</td>
              <td>&nbsp;Mode 1</td>
              <td>&nbsp;OKH</td>
              <td>&nbsp;Deactivation take around 4-5 min before its activated</td>
              <td>&nbsp;1</td>
            </tr>
            <tr> 
              <td>&nbsp;Nokia</td>
              <td>&nbsp;6021</td>
              <td>&nbsp;Supported</td>
              <td>&nbsp;Manual</td>
              <td>&nbsp;Mode 2</td>
              <td>&nbsp;OKH</td>
              <td>&nbsp;Deactivation take around 4-5 min before its activated</td>
              <td>&nbsp;1</td>
            </tr>
            <tr> 
              <td>&nbsp;Nokia</td>
              <td>&nbsp;6500</td>
              <td>&nbsp;Supported</td>
              <td>&nbsp;Manual</td>
              <td>&nbsp;Mode 1</td>
              <td>&nbsp;OKH</td>
              <td>&nbsp;Deactivation take around 4-5 min before its activated</td>
              <td>&nbsp;1</td>
            </tr>
            <tr> 
              <td>&nbsp;Nokia</td>
              <td>&nbsp;5300 Express</td>
              <td>&nbsp;Supported</td>
              <td>&nbsp;Manual</td>
              <td>&nbsp;Mode 1</td>
              <td>&nbsp;OKH</td>
              <td>&nbsp;Deactivation take around 4-5 min before its activated</td>
              <td>&nbsp;1</td>
            </tr>
            <tr> 
              <td>&nbsp;Nokia</td>
              <td>&nbsp;1680</td>
              <td>&nbsp;Supported</td>
              <td>&nbsp;Manual</td>
              <td>&nbsp;Mode 1</td>
              <td>&nbsp;OKH</td>
              <td>&nbsp;Deactivation take around 4-5 min before its activated</td>
              <td>&nbsp;1</td>
            </tr>
            <tr> 
              <td>&nbsp;SE</td>
              <td>&nbsp;C902</td>
              <td>&nbsp;Supported</td>
              <td>&nbsp;Auto Reboot</td>
              <td>&nbsp;Mode 1</td>
              <td>&nbsp;OKH</td>
              <td>&nbsp;Deactivation take around 4-5 min before its activated</td>
              <td>&nbsp;1</td>
            </tr>
            <tr> 
              <td>&nbsp;SE</td>
              <td>&nbsp;M600i</td>
              <td>&nbsp;Supported</td>
              <td>&nbsp;Auto Reboot</td>
              <td>&nbsp;Mode 1</td>
              <td>&nbsp;OKH</td>
              <td>&nbsp;</td>
              <td>&nbsp;1</td>
            </tr>
            <tr> 
              <td>&nbsp;SE</td>
              <td>&nbsp;W580i</td>
              <td>&nbsp;Not Supported</td>
              <td>&nbsp;Not Supported</td>
              <td>&nbsp;Not Supported</td>
              <td>&nbsp;OKH</td>
              <td>&nbsp;Not supported</td>
              <td>&nbsp;1</td>
            </tr>
            <tr> 
              <td>&nbsp;SE</td>
              <td>&nbsp;W750i</td>
              <td>&nbsp;Supported</td>
              <td>&nbsp;Auto Reboot</td>
              <td>&nbsp;Mode 1</td>
              <td>&nbsp;OKH</td>
              <td>&nbsp;Deactivation take around 4-5 min before its activated</td>
              <td>&nbsp;1</td>
            </tr>
          </tbody>
        </table>
<script language="javascript" type="text/javascript">
	jq = jQuery.noConflict();
	jq('table tr:not(:first-child):even').css('background-color', '#f0f0f0');
</script>