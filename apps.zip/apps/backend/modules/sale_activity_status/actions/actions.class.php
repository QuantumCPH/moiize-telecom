<?php

/**
 * sale_activity_status actions.
 *
 * @package    zapnacrm
 * @subpackage sale_activity_status
 * @author     Your name here
 * @version    SVN: $Id: actions.class.php 5125 2007-09-16 00:53:55Z dwhittle $
 */
class sale_activity_statusActions extends autosale_activity_statusActions
{
}
