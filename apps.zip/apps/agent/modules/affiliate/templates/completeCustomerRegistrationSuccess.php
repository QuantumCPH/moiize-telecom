<?php
	
?>
<p>
	<strong>Customer is registered successfully.</strong>
</p>