    <td><?php echo $company->getName() ?></td>
      <td><?php echo $company->getVatNo() ?></td>
      <td><?php echo $company->getContactName() ?></td>
      <td><?php echo $company->getHeadPhoneNumber() ?></td>
  