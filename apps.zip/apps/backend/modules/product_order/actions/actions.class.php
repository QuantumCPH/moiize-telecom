<?php

/**
 * product_order actions.
 *
 * @package    zapnacrm
 * @subpackage product_order
 * @author     Your name here
 * @version    SVN: $Id: actions.class.php 5125 2007-09-16 00:53:55Z dwhittle $
 */
class product_orderActions extends autoproduct_orderActions
{
	function executeEdit($request)
	{
		parent::executeEdit($request);
	}
}
