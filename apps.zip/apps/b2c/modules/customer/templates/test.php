<?php 
$brush_price = 5; 

for ( $counter = 10; $counter <= 100; $counter += 10) {
	
	echo $counter;
	echo "\r\n";
	
}

?>