<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

?>

<?php include_partial('agent_user/form', array('form' => $form)) ?>
