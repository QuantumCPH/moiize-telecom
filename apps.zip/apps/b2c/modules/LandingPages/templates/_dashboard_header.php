<table width="780">
    <tr>
        <td>
            <?php echo image_tag("/zerocall/images/logo.jpg") ?>
        </td>
    </tr>
    <td>&nbsp;</td>
    <tr>
        <td style="height:119px;background: #fff url(<?php echo _compute_public_path('sub-page-bg','zerocall/images','jpg') ?>) left no-repeat;">
            <h2 style="color: #fff; font-size: 26px; padding-left: 10px; "><?php echo __('Welcome') ?> - <span>'Mobillgere til hele verden'</span> </h2>
        </td>
    </tr>
</table>

    
