<div id="employee_id_zone">
	Please select a company first
</div>