<h1>New Usage alert sender</h1>

<?php include_partial('form', array('form' => $form)) ?>
