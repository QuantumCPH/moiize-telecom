<td colspan="4">
    <?php echo $company->getName() ?>
     - 
    <?php echo $company->getVatNo() ?>
     - 
    <?php echo $company->getContactName() ?>
     - 
    <?php echo $company->getHeadPhoneNumber() ?>
     - 
</td>