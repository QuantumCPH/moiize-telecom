<?php
echo "your payment has been accepted ";
?>