<?php

class agentConfiguration extends sfApplicationConfiguration
{
  public function configure()
  {
  }
}
