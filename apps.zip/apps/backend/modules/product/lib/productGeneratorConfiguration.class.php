<?php

/**
 * product module configuration.
 *
 * @package    zapnacrm
 * @subpackage product
 * @author     Your name here
 * @version    SVN: $Id: productGeneratorConfiguration.class.php,v 1.1 2010-05-25 13:17:33 orehman Exp $
 */
class productGeneratorConfiguration extends BaseProductGeneratorConfiguration
{
}
