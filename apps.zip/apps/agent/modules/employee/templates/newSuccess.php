<h1>New Employee</h1>

<?php include_partial('form', array('form' => $form)) ?>
