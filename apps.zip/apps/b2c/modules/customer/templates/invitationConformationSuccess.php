<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

?>



  
<h1>Invitation has been sent successfully </h1>
<a href="/b2c_dev.php/customer/Dashboard"> <button >Back To Home</button></a>
