<h1>Edit Agent company</h1>

<?php include_partial('form', array('form' => $form)) ?>
