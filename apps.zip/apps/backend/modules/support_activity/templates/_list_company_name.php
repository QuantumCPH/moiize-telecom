<?php
  echo $support_activity->getEmployee()?
  	$support_activity->getEmployee()->getCompany()?$support_activity->getEmployee()->getCompany():'N/A'
  	:'N/A';
	
?>