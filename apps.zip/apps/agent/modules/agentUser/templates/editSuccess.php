<h1>Edit AgentUser</h1>

<?php include_partial('form', array('form' => $form)) ?>
