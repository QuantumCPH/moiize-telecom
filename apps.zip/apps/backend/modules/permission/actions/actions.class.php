<?php

/**
 * permission actions.
 *
 * @package    zapnacrm
 * @subpackage permission
 * @author     Your name here
 * @version    SVN: $Id: actions.class.php 5125 2007-09-16 00:53:55Z dwhittle $
 */
class permissionActions extends autopermissionActions
{
}
