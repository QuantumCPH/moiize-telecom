<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

?>
<h1>De-Activate Customer</h1>

<form action="" method="get">
    <label>Customer Id:</label>
    <input type="text" name="customer_id" />

    <input type="submit" value="De-Activate">
</form>

<br/>
<?php echo $response_text ?>
