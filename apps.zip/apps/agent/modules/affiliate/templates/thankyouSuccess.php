
  <div class="left-col">
	<div align="center" style="margin:50px auto">
	<?php
		echo __("<p>Thank you for recharging your account at LandNCall AB. You will receive a confirmation email along with invoice in few moments.</p>");
		echo __("<p>Your account balance will be updated as soon as possible.</p>");
		echo __("<p>For any questions please feel free to contact us at");
	?>
	<a href="mailto:support@landncall.com">support@landncall.com</a>.
	</div>
  </div> <!-- end left-col -->
