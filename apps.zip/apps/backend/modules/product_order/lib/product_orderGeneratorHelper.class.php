<?php

/**
 * product_order module helper.
 *
 * @package    zapnacrm
 * @subpackage product_order
 * @author     Your name here
 * @version    SVN: $Id: helper.php 12474 2008-10-31 10:41:27Z fabien $
 */
class product_orderGeneratorHelper extends BaseProduct_orderGeneratorHelper
{
}
