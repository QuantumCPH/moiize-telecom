<?php

/**
 * apartment_form actions.
 *
 * @package    zapnacrm
 * @subpackage apartment_form
 * @author     Your name here
 * @version    SVN: $Id: actions.class.php 5125 2007-09-16 00:53:55Z dwhittle $
 */
class apartment_formActions extends autoapartment_formActions
{
}
